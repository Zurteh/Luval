package me.luval.client.impl.modules;

import org.lwjgl.input.Keyboard;

import me.luval.client.api.event.EventTarget;
import me.luval.client.api.event.events.EventMove;
import me.luval.client.api.module.Category;
import me.luval.client.api.module.Module;
import net.minecraft.util.EnumFacing;

import static net.minecraft.client.Minecraft.thePlayer;

//CHANGE TO SPEED.JAVA OR COPY CODE TO SPEED.JAVA
public class MineplexSpeed extends Module {

	public MineplexSpeed() {
		super("MemePlexSpeed", Keyboard.KEY_V, Category.MOVE, "null");
	}

}
