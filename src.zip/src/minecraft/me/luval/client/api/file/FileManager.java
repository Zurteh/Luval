package me.luval.client.api.file;

public class FileManager {

}
