package me.luval.client.api.module;

public enum Category {
	COMBAT, MOVE, PLAYER, VISUALS, NONE
}
