package me.luval.client.api.event.events;

import me.luval.client.api.event.Event;

public class EventUpdate extends Event{}
