package net.minecraft.client.gui.spectator;

import java.util.List;
import net.minecraft.util.IChatComponent;

public interface ISpectatorMenuView
{
    List func_178669_a();

    IChatComponent func_178670_b();
}
